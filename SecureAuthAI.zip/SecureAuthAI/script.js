
let realOTP = "1234";

function login() {

    let user = document.getElementById("username").value;
    let pass = document.getElementById("password").value;

    if (user == "admin" && pass == "1234") {

        alert("OTP sent to user");

        window.location = "otp.html";

    } else {

        document.getElementById("msg").innerHTML =
        "⚠ Invalid Login";

    }
}



function verifyOTP() {

    let otp = document.getElementById("otp").value;

    if (otp == realOTP) {

        let risk = Math.random();

        if (risk > 0.7) {

            alert("⚠ Suspicious Login Detected");
            window.location = "index.html";

        } else {

            window.location = "dashboard.html";

        }

    } else {

        document.getElementById("msg").innerHTML =
        "Wrong OTP";

    }

}