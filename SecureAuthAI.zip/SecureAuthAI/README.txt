SecureAuth AI – Cybersecurity Login Prototype

This project is a cybersecurity themed login system
with password, OTP and suspicious login detection.

Made for Hackathon Project.